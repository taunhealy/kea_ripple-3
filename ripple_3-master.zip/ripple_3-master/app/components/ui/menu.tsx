"use client";

interface MenuProps {
  isOpen: boolean;
}

export function Menu({ isOpen }: MenuProps) {
  return <nav>{/* Add your menu items here */}</nav>;
}
