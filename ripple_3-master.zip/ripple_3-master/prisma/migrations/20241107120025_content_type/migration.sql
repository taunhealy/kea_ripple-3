-- AlterEnum
ALTER TYPE "ContentType" ADD VALUE 'REQUESTS';
