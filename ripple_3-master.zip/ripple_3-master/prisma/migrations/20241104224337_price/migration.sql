-- AlterTable
ALTER TABLE "PresetUpload" ADD COLUMN     "price" DOUBLE PRECISION;
