export interface SidebarSettings {
  disabled?: boolean;
}
